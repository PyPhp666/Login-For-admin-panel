
<head><title>login</title></head>

<?php
if (isset($_POST['log']))
{
	if ($_POST['hg'] == 'root') {
		if ($_POST['gh'] == 'toor'){
			echo 'sucessfull';
		}
	}elseif ($_POST['hg'] != 'root') {
		echo '---неправильное имя!!!---';
	}
	if ($_POST['gh'] != 'toor') {
		echo '---неправильный пароль!!!---';
	}
}
?>

<style type="text/css">
	.hgg {
		background: ccc;
	}
	.hgj {
		background: red;
		color: ccc;
	}
	.kkk {
		padding: 200px;
	}
	.texttxt {
		color: red;
	}
	.ttx {
		background-color: gray;
		color: red;
	}
</style>

<form method="POST">
	<div class="kkk">
		<h1 class="texttxt" align="center">логин</h1>
		<hr/>
		<p>-имя-</p>
		<input type="input" name="hg" value="---" class="hgg">
		<hr/>
		<p>-пароль-</p>
		<input type="password" name="gh" value="---" class="hgg">
		<hr/>
	    <input type="submit" name="log" value="войти" class="hgj">
	    <p class="ttx">войдите в аккаунт чтобы продолжить</p>
	    <hr/>
	</div>
</form>